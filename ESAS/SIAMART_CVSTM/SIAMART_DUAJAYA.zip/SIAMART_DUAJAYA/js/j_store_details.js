jQuery(
	function()
	{
		jQuery('.scrollable').jScrollPane({showArrows:true, scrollbarWidth:30});
	}
);